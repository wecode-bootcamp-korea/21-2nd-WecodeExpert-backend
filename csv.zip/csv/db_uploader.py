import django
import csv
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "wecode_expert.settings")
django.setup()

from users.models import *
from products.models import *
from orders.models import *

with open('csv/expert_csv - user.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        User.objects.create(**row)

with open('csv/expert_csv - sellerinfo.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        SellerInfo.objects.create(**row)

with open('csv/expert_csv - position.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        Position.objects.create(**row)

with open('csv/expert_csv - expert.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        Expert.objects.create(**row)

with open('csv/expert_csv - category.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        Category.objects.create(**row)

with open('csv/expert_csv - categoryexpert.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        CategoryExpert.objects.create(**row)

with open('csv/expert_csv - product.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        Product.objects.create(**row)

with open('csv/expert_csv - review.csv', newline='') as csvfile:
    data_reader = csv.DictReader(csvfile)
    for row in data_reader:
        Review.objects.create(**row)

# with open('csv/expert_csv - like.csv', newline='') as csvfile:
#     data_reader = csv.DictReader(csvfile)
#     for row in data_reader:
#         Like.objects.create(**row)

# with open('csv/expert_csv - hashtag.csv', newline='') as csvfile:
#     data_reader = csv.DictReader(csvfile)
#     for row in data_reader:
#         HashTag.objects.create(**row)

# with open('csv/expert_csv - order.csv', newline='') as csvfile:
#     data_reader = csv.DictReader(csvfile)
#     for row in data_reader:
#         Order.objects.create(**row)